/*
# Create messages table for contact form submissions

1. New Tables
- `messages`
  - `id` (uuid, primary key, auto-generated)
  - `name` (text, not null) — sender's full name
  - `email` (text, not null) — sender's email address
  - `phone` (text, nullable) — optional phone number
  - `message` (text, not null) — the message content
  - `read` (boolean, default false) — whether the owner has read the message
  - `created_at` (timestamptz, default now()) — when the message was sent

2. Security
- Enable RLS on `messages`.
- Allow anyone (anon + authenticated) to INSERT messages — this is a public contact form with no login.
- No SELECT/UPDATE/DELETE for anon — only the owner (via authenticated/dashboard) can read or manage messages.
- Note: For now, the owner can view messages directly in the Supabase dashboard. SELECT/UPDATE/DELETE policies are scoped to authenticated for future admin access.
*/

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  message text NOT NULL,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Allow anyone to submit a message via the contact form
DROP POLICY IF EXISTS "anon_insert_messages" ON messages;
CREATE POLICY "anon_insert_messages" ON messages FOR INSERT
  TO anon, authenticated WITH CHECK (true);

-- Only authenticated users (owner) can read messages
DROP POLICY IF EXISTS "auth_select_messages" ON messages;
CREATE POLICY "auth_select_messages" ON messages FOR SELECT
  TO authenticated USING (true);

-- Only authenticated users (owner) can mark messages as read
DROP POLICY IF EXISTS "auth_update_messages" ON messages;
CREATE POLICY "auth_update_messages" ON messages FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- Only authenticated users (owner) can delete messages
DROP POLICY IF EXISTS "auth_delete_messages" ON messages;
CREATE POLICY "auth_delete_messages" ON messages FOR DELETE
  TO authenticated USING (true);
