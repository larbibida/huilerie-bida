import { useEffect, useState } from 'react';
import { Menu, X, Globe, Check } from 'lucide-react';
import { useLang } from '@/i18n/LanguageContext';
import { languages, type Lang } from '@/i18n/translations';

export default function Navbar() {
  const { t, lang, setLang } = useLang();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-bark-900/95 backdrop-blur-md shadow-lg shadow-black/20 py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <nav className="mx-auto max-w-7xl px-6 flex items-center justify-between">
      <a href="#home" className="flex items-center gap-2.5 group">
          <img src="/ChatGPT_Image_13_sept._2026,_12_07_01.png" alt="Huilerie Bida logo" className="h-12 w-13 rounded-full ring-1 ring-gold-400/50 transition-transform group-hover:scale-110" />
          <div className="flex flex-col leading-none">
            <span className={`font-display text-xl font-bold tracking-wide transition-colors ${scrolled ? 'text-cream-50' : 'text-cream-50'}`}>
              Huilerie Bida
            </span>
            <span className={`text-[10px] uppercase tracking-[0.25em] transition-colors ${scrolled ? 'text-gold-300' : 'text-gold-200'}`}>
              {t.footer.tagline}
            </span>
          </div>
        </a>

        <ul className="hidden lg:flex items-center gap-8">
          {t.nav.links.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="relative text-sm font-medium text-cream-100/90 hover:text-gold-300 transition-colors duration-300 after:absolute after:bottom-[-4px] after:left-0 after:h-[2px] after:w-0 after:bg-gold-400 after:transition-all after:duration-300 hover:after:w-full"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden lg:flex items-center gap-4">
          {/* Language switcher */}
          <div className="relative">
            <button
              onClick={() => setLangOpen(!langOpen)}
              className="flex items-center gap-2 rounded-full border border-cream-100/20 px-3 py-2 text-sm text-cream-100/90 transition-colors hover:border-cream-100/40 hover:text-gold-300"
            >
              <Globe className="h-4 w-4" />
              <span className="font-medium uppercase">{lang}</span>
            </button>
            {langOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setLangOpen(false)} />
                <div className="absolute right-0 mt-2 z-20 w-44 rounded-xl bg-bark-800 shadow-xl border border-cream-100/10 overflow-hidden">
                  {languages.map((l) => (
                    <button
                      key={l.code}
                      onClick={() => { setLang(l.code as Lang); setLangOpen(false); }}
                      className={`flex w-full items-center justify-between px-4 py-2.5 text-sm transition-colors ${
                        lang === l.code ? 'bg-gold-500/15 text-gold-300' : 'text-cream-100/80 hover:bg-bark-700'
                      }`}
                    >
                      <span>{l.label}</span>
                      {lang === l.code && <Check className="h-4 w-4" />}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          <a
            href="#contact"
            className="inline-flex items-center rounded-full bg-gold-500 px-6 py-2.5 text-sm font-semibold text-bark-900 hover:bg-gold-400 transition-all duration-300 hover:shadow-lg hover:shadow-gold-500/30 hover:-translate-y-0.5"
          >
            {t.nav.cta}
          </a>
        </div>

        <button
          onClick={() => setOpen(!open)}
          className="lg:hidden text-cream-50 p-2"
          aria-label="Menu"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        className={`lg:hidden overflow-hidden transition-all duration-500 ${
          open ? 'max-h-[600px] opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <ul className="mx-6 mt-4 space-y-1 rounded-2xl bg-bark-800/95 backdrop-blur-md p-4 shadow-xl">
          {t.nav.links.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                onClick={() => setOpen(false)}
                className="block rounded-xl px-4 py-3 text-cream-100 hover:bg-olive-700/50 hover:text-gold-300 transition-colors"
              >
                {link.label}
              </a>
            </li>
          ))}
          {/* Mobile language switcher */}
          <li className="px-4 py-2 flex items-center gap-3">
            {languages.map((l) => (
              <button
                key={l.code}
                onClick={() => setLang(l.code as Lang)}
                className={`rounded-lg px-3 py-1.5 text-sm font-medium uppercase transition-colors ${
                  lang === l.code ? 'bg-gold-500 text-bark-900' : 'bg-bark-700 text-cream-100/70'
                }`}
              >
                {l.code}
              </button>
            ))}
          </li>
          <li>
            <a
              href="#contact"
              onClick={() => setOpen(false)}
              className="block rounded-xl bg-gold-500 px-4 py-3 text-center font-semibold text-bark-900 mt-2"
            >
              {t.nav.cta}
            </a>
          </li>
        </ul>
      </div>
    </header>
  );
}
