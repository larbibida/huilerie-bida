import { ChevronDown } from 'lucide-react';
import { useLang } from '@/i18n/LanguageContext';

const heroImage = 'https://images.pexels.com/photos/34803738/pexels-photo-34803738.jpeg?auto=compress&cs=tinysrgb&w=1920';

export default function Hero() {
  const { t } = useLang();

  return (
    <section id="home" className="relative min-h-screen w-full overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Olive grove under a blue sky"
          className="h-full w-full object-cover animate-slow-zoom"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-bark-900/60 via-bark-900/40 to-bark-950/80" />
        <div className="absolute inset-0 bg-gradient-to-r from-bark-950/50 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto flex min-h-screen max-w-7xl flex-col justify-center px-6 pt-24">
        <div className="max-w-2xl">
          <p className="reveal mb-6 flex items-center gap-3 text-gold-300">
            <span className="h-[1px] w-12 bg-gold-400" />
            <span className="text-sm uppercase tracking-[0.3em] font-medium">{t.hero.badge}</span>
          </p>
          <h1 className="reveal reveal-delay-1 font-display text-5xl sm:text-6xl lg:text-7xl font-bold leading-[1.1] text-cream-50 text-balance">
            {t.hero.title1}
            <span className="block italic text-gold-300">{t.hero.title2}</span>
          </h1>
          <p className="reveal reveal-delay-2 mt-8 max-w-xl text-lg leading-relaxed text-cream-100/80">
            {t.hero.desc}
          </p>
          <div className="reveal reveal-delay-3 mt-10 flex flex-wrap gap-4">
            <a
              href="#products"
              className="group inline-flex items-center gap-2 rounded-full bg-gold-500 px-8 py-4 text-base font-semibold text-bark-900 transition-all duration-300 hover:bg-gold-400 hover:shadow-xl hover:shadow-gold-500/30 hover:-translate-y-0.5"
            >
              {t.hero.cta1}
              <ChevronDown className="h-4 w-4 transition-transform group-hover:translate-y-1" />
            </a>
            <a
              href="#story"
              className="inline-flex items-center gap-2 rounded-full border border-cream-100/30 px-8 py-4 text-base font-medium text-cream-50 backdrop-blur-sm transition-all duration-300 hover:bg-cream-50/10 hover:border-cream-100/50"
            >
              {t.hero.cta2}
            </a>
          </div>
        </div>

        {/* Stats bar */}
        <div className="reveal reveal-delay-4 mt-16 flex flex-wrap gap-8 sm:gap-16 border-t border-cream-100/15 pt-8">
          {t.hero.stats.map((stat) => (
            <div key={stat.label}>
              <p className="font-display text-3xl font-bold text-gold-300">{stat.value}</p>
              <p className="mt-1 text-sm text-cream-100/70">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10">
        <div className="flex h-10 w-6 items-start justify-center rounded-full border-2 border-cream-100/30 p-1.5">
          <span className="h-2 w-1 rounded-full bg-gold-300 animate-bounce" />
        </div>
      </div>
    </section>
  );
}
