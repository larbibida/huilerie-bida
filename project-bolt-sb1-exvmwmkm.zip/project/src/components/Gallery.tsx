import { useLang } from '@/i18n/LanguageContext';

const images = [
  {
    src: 'https://images.pexels.com/photos/5283373/pexels-photo-5283373.jpeg?auto=compress&cs=tinysrgb&w=800',
    span: 'lg:row-span-2',
  },
  {
    src: 'https://images.pexels.com/photos/31667167/pexels-photo-31667167.jpeg?auto=compress&cs=tinysrgb&w=600',
    span: '',
  },
  {
    src: 'https://images.pexels.com/photos/5737246/pexels-photo-5737246.jpeg?auto=compress&cs=tinysrgb&w=600',
    span: '',
  },
  {
    src: 'https://images.pexels.com/photos/29020602/pexels-photo-29020602.jpeg?auto=compress&cs=tinysrgb&w=800',
    span: 'lg:col-span-2',
  },
  {
    src: 'https://images.pexels.com/photos/1022385/pexels-photo-1022385.jpeg?auto=compress&cs=tinysrgb&w=600',
    span: '',
  },
];

export default function Gallery() {
  const { t } = useLang();

  return (
    <section id="gallery" className="relative py-28 lg:py-36 bg-cream-50">
      <div className="mx-auto max-w-7xl px-6">
        {/* Header */}
        <div className="reveal mx-auto max-w-2xl text-center mb-16">
          <p className="mb-4 flex items-center justify-center gap-3 text-olive-600">
            <span className="h-[1px] w-10 bg-olive-500" />
            <span className="text-sm uppercase tracking-[0.25em] font-semibold">{t.gallery.tag}</span>
            <span className="h-[1px] w-10 bg-olive-500" />
          </p>
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-bark-900 leading-tight text-balance">
            {t.gallery.title1}
            <span className="block italic text-olive-600">{t.gallery.title2}</span>
          </h2>
        </div>

        {/* Grid */}
        <div className="reveal grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-5 auto-rows-[200px] lg:auto-rows-[240px]">
          {images.map((img, i) => (
            <div
              key={i}
              className={`group relative overflow-hidden rounded-2xl shadow-md cursor-pointer ${img.span}`}
            >
              <img
                src={img.src}
                alt={t.gallery.labels[i]}
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-bark-950/70 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
              <div className="absolute bottom-0 left-0 right-0 p-5 translate-y-4 opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                <p className="font-display text-lg font-semibold text-cream-50">{t.gallery.labels[i]}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
