import { useState } from 'react';
import { Sprout, Hand, Droplets, FlaskRound, Package, Play, X } from 'lucide-react';
import { useLang } from '@/i18n/LanguageContext';

const stepIcons = [Sprout, Hand, FlaskRound, Droplets, Package];

const videoSources = [
  '/Notre Procédé/vd1.mp4',
  '/Notre Procédé/vd3.mp4',
];

export default function Process() {
  const { t } = useLang();
  const [activeVideo, setActiveVideo] = useState<string | null>(null);

  return (
    <section id="process" className="relative py-28 lg:py-36 bg-cream-100 overflow-hidden">
      <div className="relative mx-auto max-w-7xl px-6">
        {/* Header */}
        <div className="reveal mx-auto max-w-2xl text-center">
          <p className="mb-4 flex items-center justify-center gap-3 text-olive-600">
            <span className="h-[1px] w-10 bg-olive-500" />
            <span className="text-sm uppercase tracking-[0.25em] font-semibold">{t.process.tag}</span>
            <span className="h-[1px] w-10 bg-olive-500" />
          </p>
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-bark-900 leading-tight text-balance">
            {t.process.title1}
            <span className="block italic text-olive-600">{t.process.title2}</span>
          </h2>
          <p className="mt-6 text-bark-600 leading-relaxed">
            {t.process.desc}
          </p>
        </div>

        {/* Steps */}
        <div className="mt-20 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {t.process.steps.map((step, i) => {
            const Icon = stepIcons[i];
            return (
              <div
                key={step.title}
                className={`reveal reveal-delay-${Math.min(i + 1, 4)} group relative`}
              >
                {/* Connector line (desktop) */}
                {i < t.process.steps.length - 1 && (
                  <div className="hidden lg:block absolute top-12 left-[60%] right-[-40%] h-[2px] bg-gradient-to-r from-olive-300 to-olive-100" />
                )}

                <div className="relative flex flex-col items-center text-center">
                  <div className="relative mb-6">
                    <div className="flex h-24 w-24 items-center justify-center rounded-full bg-white shadow-lg shadow-olive-900/8 transition-all duration-500 group-hover:shadow-xl group-hover:shadow-olive-900/12 group-hover:-translate-y-1">
                      <Icon className="h-10 w-10 text-olive-600" strokeWidth={1.5} />
                    </div>
                    <span className="absolute -top-2 -right-2 flex h-8 w-8 items-center justify-center rounded-full bg-gold-500 text-xs font-bold text-bark-900 shadow-md">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                  </div>
                  <h3 className="font-display text-xl font-bold text-bark-900">{step.title}</h3>
                  <p className="mt-3 text-sm text-bark-600 leading-relaxed">{step.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Videos */}
        <div className="mt-20 grid md:grid-cols-2 gap-8">
          {t.process.videos.map((video, i) => (
            <div
              key={video.title}
              className={`reveal reveal-delay-${Math.min(i + 1, 4)} group relative overflow-hidden rounded-2xl shadow-xl shadow-bark-900/10 cursor-pointer`}
              onClick={() => setActiveVideo(videoSources[i])}
            >
              <video
                src={videoSources[i]}
                className="w-full h-64 lg:h-80 object-cover transition-transform duration-700 group-hover:scale-105"
                muted
                loop
                autoPlay
                playsInline
                preload="metadata"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-bark-950/80 via-bark-950/10 to-transparent pointer-events-none" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex h-16 w-16 items-center justify-center rounded-full bg-cream-50/90 shadow-lg transition-all duration-300 group-hover:scale-110 group-hover:bg-cream-50">
                <Play className="h-7 w-7 text-olive-700 ml-1" fill="currentColor" />
              </div>
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="font-display text-xl font-bold text-cream-50">{video.title}</h3>
                <p className="mt-1 text-sm text-cream-100/80">{video.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Lightbox */}
        {activeVideo && (
          <div
            className="fixed inset-0 z-[100] flex items-center justify-center bg-bark-950/90 backdrop-blur-sm p-4"
            onClick={() => setActiveVideo(null)}
          >
            <button
              className="absolute top-6 right-6 flex h-12 w-12 items-center justify-center rounded-full bg-cream-50/10 text-cream-50 transition-colors hover:bg-cream-50/20"
              onClick={() => setActiveVideo(null)}
              aria-label="Close"
            >
              <X className="h-6 w-6" />
            </button>
            <video
              src={activeVideo}
              className="max-h-[85vh] max-w-[90vw] rounded-xl shadow-2xl"
              controls
              autoPlay
              playsInline
              onClick={(e) => e.stopPropagation()}
            />
          </div>
        )}
      </div>
    </section>
  );
}
