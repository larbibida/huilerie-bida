import { ShoppingBag, Check } from 'lucide-react';
import { useLang } from '@/i18n/LanguageContext';

const productImages = [
  '/nos produits/authentic/WhatsApp_Image_2026-10-09_at_7.03.03_PM_(2).jpeg',
  '/nos produits/limited edition/WhatsApp_Image_2026-10-09_at_7.03.03_PM.jpeg',
  '/nos produits/la tradition/0.5l.jpeg',
];

export default function Products() {
  const { t } = useLang();

  return (
    <section id="products" className="relative py-28 lg:py-36 bg-bark-900 overflow-hidden">
      {/* Decorative gradient */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 h-96 w-96 rounded-full bg-olive-700/20 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-6">
        {/* Header */}
        <div className="reveal mx-auto max-w-2xl text-center">
          <p className="mb-4 flex items-center justify-center gap-3 text-gold-300">
            <span className="h-[1px] w-10 bg-gold-400" />
            <span className="text-sm uppercase tracking-[0.25em] font-semibold">{t.products.tag}</span>
            <span className="h-[1px] w-10 bg-gold-400" />
          </p>
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-cream-50 leading-tight text-balance">
            {t.products.title1}
            <span className="block italic text-gold-300">{t.products.title2}</span>
          </h2>
          <p className="mt-6 text-cream-100/70 leading-relaxed">
            {t.products.desc}
          </p>
        </div>

        {/* Product cards */}
        <div className="mt-16 grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {t.products.items.map((product, i) => (
            <div
              key={product.name}
              className={`reveal reveal-delay-${i + 1} group relative flex flex-col overflow-hidden rounded-3xl transition-all duration-500 hover:-translate-y-2 ${
                i === 1
                  ? 'bg-gradient-to-b from-gold-900/40 to-bark-800 ring-2 ring-gold-500/40 lg:scale-105'
                  : 'bg-bark-800 ring-1 ring-cream-100/5'
              }`}
            >
              {/* Badge */}
              {product.badge && (
                <div className="absolute top-5 left-5 z-10">
                  <span
                    className={`rounded-full px-4 py-1.5 text-xs font-semibold uppercase tracking-wider ${
                      i === 1
                        ? 'bg-gold-400 text-bark-900'
                        : 'bg-olive-600 text-cream-50'
                    }`}
                  >
                    {product.badge}
                  </span>
                </div>
              )}

              {/* Image */}
              <div className="relative h-72 overflow-hidden">
                <img
                  src={productImages[i]}
                  alt={product.name}
                  className="h-full w-full  transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-bark-900 via-transparent to-transparent" />
              </div>

              {/* Content */}
              <div className="flex flex-1 flex-col p-7">
                <p className="text-xs uppercase tracking-[0.2em] text-gold-300/80">{product.subtitle}</p>
                <h3 className="mt-2 font-display text-2xl font-bold text-cream-50">{product.name}</h3>
                <p className="mt-3 text-sm text-cream-100/70 leading-relaxed flex-1">{product.description}</p>

                {/* Features */}
                <ul className="mt-5 space-y-2">
                  {product.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2.5 text-sm text-cream-100/80">
                      <Check className="h-4 w-4 shrink-0 text-gold-400" />
                      {feature}
                    </li>
                  ))}
                </ul>

                {/* Price & CTA */}
                <div className="mt-7 flex items-center justify-between border-t border-cream-100/10 pt-5">
                  <div>
                    <p className="font-display text-2xl font-bold text-gold-300"></p>
                    <p className="text-xs text-cream-100/50">{product.volume}</p>
                  </div>
                  <a
                    href="#contact"
                    className={`inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition-all duration-300 hover:shadow-lg ${
                      i === 1
                        ? 'bg-gold-400 text-bark-900 hover:bg-gold-300'
                        : 'bg-olive-600 text-cream-50 hover:bg-olive-500'
                    }`}
                  >
                    <ShoppingBag className="h-4 w-4" />
                    {t.products.cta}
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Note */}
        <p className="reveal reveal-delay-4 mt-12 text-center text-sm text-cream-100/50">
          {t.products.note}
        </p>
      </div>
    </section>
  );
}
