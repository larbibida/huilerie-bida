import { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, Check, AlertCircle, Loader2 } from 'lucide-react';
import { useLang } from '@/i18n/LanguageContext';
import { supabase } from '@/lib/supabase';

const contactIcons = [MapPin, Phone, Mail, Clock];

type Status = 'idle' | 'sending' | 'sent' | 'error';

export default function Contact() {
  const { t } = useLang();
  const [status, setStatus] = useState<Status>('idle');
  const [form, setForm] = useState({ name: '', email: '', phone: '', message: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('sending');

    const { error } = await supabase.from('messages').insert({
      name: form.name,
      email: form.email,
      phone: form.phone || null,
      message: form.message,
    });

    if (error) {
      setStatus('error');
      setTimeout(() => setStatus('idle'), 5000);
      return;
    }

    setStatus('sent');
    setForm({ name: '', email: '', phone: '', message: '' });
    setTimeout(() => setStatus('idle'), 5000);
  };

  return (
    <section id="contact" className="relative py-28 lg:py-36 bg-cream-50 overflow-hidden">
      <div className="absolute -top-20 left-1/2 -translate-x-1/2 h-72 w-72 rounded-full bg-gold-100/60 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-6">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* Left: Info */}
          <div className="reveal">
            <p className="mb-4 flex items-center gap-3 text-olive-600">
              <span className="h-[1px] w-10 bg-olive-500" />
              <span className="text-sm uppercase tracking-[0.25em] font-semibold">{t.contact.tag}</span>
            </p>
            <h2 className="font-display text-4xl lg:text-5xl font-bold text-bark-900 leading-tight text-balance">
              {t.contact.title1}
              <span className="block italic text-olive-600">{t.contact.title2}</span>
            </h2>
            <p className="mt-6 text-bark-600 leading-relaxed">
              {t.contact.desc}
            </p>

            <div className="mt-10 space-y-5">
              {t.contact.info.map((info, i) => {
                const Icon = contactIcons[i];
                return (
                  <div key={info.label} className="flex items-start gap-4 group">
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-olive-100 text-olive-700 transition-all group-hover:bg-olive-600 group-hover:text-cream-50">
                      <Icon className="h-5 w-5" />
                    </span>
                    <div>
                      <p className="text-xs uppercase tracking-widest text-bark-500">{info.label}</p>
                      <p className="mt-0.5 font-medium text-bark-800">{info.value}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Map */}
            <div className="mt-10 overflow-hidden rounded-2xl shadow-lg border border-olive-100">
              <iframe
                title="Huilerie Bida — Souiga, Boumerdes"
                src=""
                className="w-full h-64 border-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>

          {/* Right: Form */}
          <div className="reveal reveal-delay-1">
            <div className="rounded-3xl bg-white shadow-xl shadow-bark-900/8 p-8 lg:p-10 border border-olive-100">
              <h3 className="font-display text-2xl font-bold text-bark-900">{t.contact.formTitle}</h3>
              <p className="mt-2 text-sm text-bark-500">{t.contact.formDesc}</p>

              {status === 'error' && (
                <div className="mt-5 flex items-center gap-3 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
                  <AlertCircle className="h-5 w-5 shrink-0" />
                  <span>{t.contact.error}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="mt-8 space-y-5">
                <div>
                  <label className="block text-sm font-medium text-bark-700 mb-1.5">{t.contact.fields.name}</label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full rounded-xl border border-olive-200 bg-cream-50 px-4 py-3 text-bark-900 placeholder-bark-400/50 outline-none transition-all focus:border-olive-500 focus:ring-2 focus:ring-olive-500/20"
                    placeholder={t.contact.fields.namePlaceholder}
                  />
                </div>
                <div className="grid sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-medium text-bark-700 mb-1.5">{t.contact.fields.email}</label>
                    <input
                      type="email"
                      required
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="w-full rounded-xl border border-olive-200 bg-cream-50 px-4 py-3 text-bark-900 placeholder-bark-400/50 outline-none transition-all focus:border-olive-500 focus:ring-2 focus:ring-olive-500/20"
                      placeholder={t.contact.fields.emailPlaceholder}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-bark-700 mb-1.5">{t.contact.fields.phone}</label>
                    <input
                      type="tel"
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      className="w-full rounded-xl border border-olive-200 bg-cream-50 px-4 py-3 text-bark-900 placeholder-bark-400/50 outline-none transition-all focus:border-olive-500 focus:ring-2 focus:ring-olive-500/20"
                      placeholder={t.contact.fields.phonePlaceholder}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-bark-700 mb-1.5">{t.contact.fields.message}</label>
                  <textarea
                    required
                    rows={4}
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    className="w-full rounded-xl border border-olive-200 bg-cream-50 px-4 py-3 text-bark-900 placeholder-bark-400/50 outline-none transition-all focus:border-olive-500 focus:ring-2 focus:ring-olive-500/20 resize-none"
                    placeholder={t.contact.fields.messagePlaceholder}
                  />
                </div>
                <button
                  type="submit"
                  disabled={status === 'sending' || status === 'sent'}
                  className={`w-full inline-flex items-center justify-center gap-2 rounded-xl px-6 py-4 text-base font-semibold transition-all duration-300 disabled:opacity-70 ${
                    status === 'sent'
                      ? 'bg-green-600 text-white'
                      : 'bg-olive-700 text-cream-50 hover:bg-olive-600 hover:shadow-lg hover:shadow-olive-700/30'
                  }`}
                >
                  {status === 'sending' ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      {t.contact.sending}
                    </>
                  ) : status === 'sent' ? (
                    <>
                      <Check className="h-5 w-5" />
                      {t.contact.sent}
                    </>
                  ) : (
                    <>
                      <Send className="h-5 w-5" />
                      {t.contact.submit}
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
