import { Facebook, Instagram, Phone, Mail, MapPin } from 'lucide-react';
import { useLang } from '@/i18n/LanguageContext';

export default function Footer() {
  const { t } = useLang();

  return (
    <footer className="relative bg-bark-950 text-cream-100/70 pt-20 pb-8 overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold-500/30 to-transparent" />

      <div className="mx-auto max-w-7xl px-6">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2.5 mb-5">
              <img src="/ChatGPT_Image_13_sept._2026,_12_07_01.png" alt="Huilerie Bida logo" className="h-11 w-11 rounded-full object-cover ring-2 ring-gold-400/50" />
              <div>
                <p className="font-display text-xl font-bold text-cream-50">Huilerie Bida</p>
                <p className="text-[10px] uppercase tracking-[0.25em] text-green-300">{t.footer.tagline}</p>
              </div>
            </div>
            <p className="text-sm leading-relaxed max-w-xs">
              {t.footer.about}
            </p>
            <div className="mt-6 flex gap-3">
              {[Facebook, Instagram].map((Icon, i) => (
                <a
                  key={i}
                  href="#www.facebook.com/huilerie.bida"
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-bark-800 text-cream-100/60 transition-all hover:bg-olive-700 hover:text-cream-50"
                >
                  <Icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-display text-base font-semibold text-cream-50 mb-5">{t.footer.navTitle}</h4>
            <ul className="space-y-3 text-sm">
              {t.nav.links.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="transition-colors hover:text-gold-300">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Products */}
          <div>
            <h4 className="font-display text-base font-semibold text-cream-50 mb-5">{t.footer.productsTitle}</h4>
            <ul className="space-y-3 text-sm">
              {t.footer.productLinks.map((link, i) => (
                <li key={i}>
                  <a href={i === 3 ? '#contact' : '#products'} className="transition-colors hover:text-gold-300">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display text-base font-semibold text-cream-50 mb-5">{t.footer.contactTitle}</h4>
            <ul className="space-y-4 text-sm">
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 shrink-0 text-gold-400 mt-0.5" />
                <span>{t.contact.info[0].value}</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-5 w-5 shrink-0 text-gold-400" />
                <span>{t.contact.info[1].value}</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-5 w-5 shrink-0 text-gold-400" />
                <span>{t.contact.info[2].value}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-16 border-t border-cream-100/10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-cream-100/50">
          <p>© {new Date().getFullYear()} Huilerie Bida. {t.footer.rights}</p>
          <p className="flex items-center gap-2">
            {t.footer.madeWith}
          </p>
        </div>
      </div>
    </footer>
  );
}
