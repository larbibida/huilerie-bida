import { Leaf, Heart, Award } from 'lucide-react';
import { useLang } from '@/i18n/LanguageContext';

const storyImage = 'https://images.pexels.com/photos/29020603/pexels-photo-29020603.jpeg?auto=compress&cs=tinysrgb&w=1200';
const detailImage = 'https://images.pexels.com/photos/31694877/pexels-photo-31694877.jpeg?auto=compress&cs=tinysrgb&w=800';

const icons = [Leaf, Heart, Award];

export default function Story() {
  const { t } = useLang();

  return (
    <section id="story" className="relative py-28 lg:py-36 bg-cream-50 overflow-hidden">
      {/* Decorative leaf pattern */}
      <div className="absolute -top-20 -right-20 h-64 w-64 rounded-full bg-olive-100/50 blur-3xl" />
      <div className="absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-gold-100/50 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Images */}
          <div className="reveal relative">
            <div className="relative overflow-hidden rounded-3xl shadow-2xl shadow-bark-900/15">
              <img
                src={storyImage}
                alt="Traditional olive harvest"
                className="w-full h-[520px] object-cover"
              />
            </div>
            <div className="absolute -bottom-8 -right-4 lg:-right-8 w-48 h-48 overflow-hidden rounded-2xl shadow-xl border-4 border-cream-50 hidden sm:block">
              <img
                src={detailImage}
                alt="Hand-picking olives"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Text */}
          <div className="reveal reveal-delay-1">
            <p className="mb-4 flex items-center gap-3 text-olive-600">
              <span className="h-[1px] w-10 bg-olive-500" />
              <span className="text-sm uppercase tracking-[0.25em] font-semibold">{t.story.tag}</span>
            </p>
            <h2 className="font-display text-4xl lg:text-5xl font-bold text-bark-900 leading-tight text-balance">
              {t.story.title1}
              <span className="block italic text-olive-600">{t.story.title2}</span>
            </h2>
            <div className="mt-6 space-y-4 text-bark-700 leading-relaxed">
              <p>{t.story.p1}</p>
              <p>{t.story.p2}</p>
            </div>

            {/* Values */}
            <div className="mt-10 space-y-5">
              {t.story.values.map((value, i) => {
                const Icon = icons[i];
                return (
                  <div
                    key={value.title}
                    className={`reveal reveal-delay-${i + 1} flex items-start gap-4 rounded-2xl bg-white/60 backdrop-blur-sm p-5 border border-olive-100 transition-all hover:bg-white hover:shadow-lg hover:shadow-olive-900/5 hover:-translate-y-0.5`}
                  >
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-olive-100 text-olive-700">
                      <Icon className="h-6 w-6" />
                    </span>
                    <div>
                      <h3 className="font-display text-lg font-semibold text-bark-900">{value.title}</h3>
                      <p className="mt-1 text-sm text-bark-600">{value.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
