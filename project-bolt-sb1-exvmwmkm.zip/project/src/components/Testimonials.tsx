import { Star, Quote } from 'lucide-react';
import { useLang } from '@/i18n/LanguageContext';

export default function Testimonials() {
  const { t } = useLang();

  return (
    <section className="relative py-28 lg:py-36 bg-gradient-to-b from-olive-800 to-bark-900 overflow-hidden">
      {/* Decorative */}
      <div className="absolute top-0 right-0 h-96 w-96 rounded-full bg-gold-500/10 blur-3xl" />
      <div className="absolute bottom-0 left-0 h-96 w-96 rounded-full bg-olive-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-6">
        {/* Header */}
        <div className="reveal mx-auto max-w-2xl text-center">
          <p className="mb-4 flex items-center justify-center gap-3 text-gold-300">
            <span className="h-[1px] w-10 bg-gold-400" />
            <span className="text-sm uppercase tracking-[0.25em] font-semibold">{t.testimonials.tag}</span>
            <span className="h-[1px] w-10 bg-gold-400" />
          </p>
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-cream-50 leading-tight text-balance">
            {t.testimonials.title1}
            <span className="block italic text-gold-300">{t.testimonials.title2}</span>
          </h2>
        </div>

        {/* Cards */}
        <div className="mt-16 grid md:grid-cols-3 gap-8">
          {t.testimonials.items.map((item, i) => (
            <div
              key={item.name}
              className={`reveal reveal-delay-${i + 1} group relative rounded-3xl bg-bark-800/60 backdrop-blur-sm p-8 ring-1 ring-cream-100/8 transition-all duration-500 hover:bg-bark-800/90 hover:ring-gold-500/20 hover:-translate-y-1.5`}
            >
              <Quote className="absolute top-6 right-6 h-10 w-10 text-gold-500/20" />

              {/* Stars */}
              <div className="flex gap-1 mb-5">
                {Array.from({ length: 5 }).map((_, idx) => (
                  <Star key={idx} className="h-5 w-5 text-gold-400" fill="currentColor" />
                ))}
              </div>

              {/* Text */}
              <p className="relative text-cream-100/85 leading-relaxed italic">
                « {item.text} »
              </p>

              {/* Author */}
              <div className="mt-7 flex items-center gap-4 border-t border-cream-100/10 pt-5">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-gold-400 to-gold-600 font-display text-lg font-bold text-bark-900">
                  {item.name.charAt(0)}
                </div>
                <div>
                  <p className="font-display font-semibold text-cream-50">{item.name}</p>
                  <p className="text-sm text-cream-100/60">{item.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
